package com.example.materialdesign;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class mascotas extends Fragment {

    private ArrayList<Mascota> mascotas;
    private RecyclerView rv_mascotas;
    public mascotaAdaptador adaptador;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_mascotas, container, false);

        rv_mascotas = (RecyclerView) v.findViewById(R.id.rv_mascotas);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rv_mascotas.setLayoutManager(llm);

        inicializaDatos();
        inicializaAdaptador();

        return v;
    }

    public void inicializaAdaptador(){
        adaptador = new mascotaAdaptador(mascotas, getActivity());
        rv_mascotas.setAdapter(adaptador);
    }

    public void inicializaDatos() {
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(R.drawable.manchi, "Manchi"));
        mascotas.add(new Mascota(R.drawable.negrito, "Negrito"));
        mascotas.add(new Mascota(R.drawable.pulgoso, "Pulgoso"));
        mascotas.add(new Mascota(R.drawable.pluto, "Pluto"));
        mascotas.add(new Mascota(R.drawable.coqueto, "Coqueto"));
        mascotas.add(new Mascota(R.drawable.linda, "Linda"));

    }
}