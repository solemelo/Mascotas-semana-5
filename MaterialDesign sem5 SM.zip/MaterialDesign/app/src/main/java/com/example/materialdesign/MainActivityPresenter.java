package com.example.materialdesign;

import android.content.Context;

import java.util.ArrayList;

public class MainActivityPresenter implements IPresenter {

    private IMainActivityView iMainActivityView;
    private Context context;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public MainActivityPresenter(IMainActivityView iMainActivityView, Context context) {
        this.iMainActivityView = iMainActivityView;
        this.context = context;
        obtenerMascotasBaseDatos();
    }


    @Override
    public void obtenerMascotasBaseDatos() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatosMascotas();
        mostrarMascotas();
    }

    @Override
    public void mostrarMascotas() {
        iMainActivityView.inicializarAdaptador(iMainActivityView.generarAdaptador(mascotas));
        iMainActivityView.crearLinearLayoutVertical();
    }
}
