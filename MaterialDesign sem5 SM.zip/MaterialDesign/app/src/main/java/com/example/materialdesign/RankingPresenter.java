package com.example.materialdesign;

import android.content.Context;

import java.util.ArrayList;

public class RankingPresenter implements IPresenter{


    private IRankingView iRankingView;
    private Context context;
    private ConstructorRanking constructorRanking;
    private ArrayList<Mascota> mascotas;

    public RankingPresenter(IRankingView iRankingView, Context context) {
        this.iRankingView = iRankingView;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        constructorRanking = new ConstructorRanking(context);
        mascotas = constructorRanking.obtenerDatosMascotas();
        mostrarMascotas();
    }

    @Override
    public void mostrarMascotas() {
        iRankingView.inicializarAdaptador(iRankingView.generarAdaptador(mascotas));
        iRankingView.crearLinearLayoutVertical();
    }
}
