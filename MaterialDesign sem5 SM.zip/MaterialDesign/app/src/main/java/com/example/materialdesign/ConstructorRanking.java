package com.example.materialdesign;

import android.content.Context;

import java.util.ArrayList;

public class ConstructorRanking {

    private Context context;

    public ConstructorRanking(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> obtenerDatosMascotas() {

        BaseDatos bd = new BaseDatos(context);
        return bd.obtenerTopMascotasFive();

    }
}
