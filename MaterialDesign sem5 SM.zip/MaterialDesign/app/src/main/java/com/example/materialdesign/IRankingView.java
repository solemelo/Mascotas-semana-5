package com.example.materialdesign;

import java.util.ArrayList;

public interface IRankingView {

    public void crearLinearLayoutVertical();
    public mascotaRankingAdaptador generarAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptador(mascotaRankingAdaptador adaptador);
}
