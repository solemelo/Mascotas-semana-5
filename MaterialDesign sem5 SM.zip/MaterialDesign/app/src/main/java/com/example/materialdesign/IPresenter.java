package com.example.materialdesign;

public interface IPresenter {

    public void obtenerMascotasBaseDatos();
    public void mostrarMascotas();
}
