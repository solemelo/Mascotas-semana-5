package com.example.materialdesign;

import java.util.ArrayList;

public interface IMainActivityView {

    public void crearLinearLayoutVertical();
    public mascotaAdaptador generarAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptador(mascotaAdaptador adaptador);
}
