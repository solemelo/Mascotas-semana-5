package com.example.materialdesign;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {

    private Context context;

    public BaseDatos(@Nullable Context context) {
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String queryCrearTablaMascota = "CREATE TABLE " + ConstantesBaseDatos.TABLE_MASCOTAS + "(" +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID                   + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE               + " TEXT, " +
                ConstantesBaseDatos.TABLE_MASCOTAS_FOTO                 + " INTEGER" +
                ")";

        String queryCrearTablaMascotaLikes = "CREATE TABLE " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA + "(" +
                ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID              + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID_MASCOTA      + " INTEGER, " +
                ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_NUMERO_PUNTAJE    + " INTEGER, " +
                "FOREIGN KEY (" + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID_MASCOTA + ")" +
                "REFERENCES " + ConstantesBaseDatos.TABLE_MASCOTAS + "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + ")" +
                ")";

        db.execSQL(queryCrearTablaMascota);
        db.execSQL(queryCrearTablaMascotaLikes);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ConstantesBaseDatos.TABLE_MASCOTAS);
        db.execSQL("DROP TABLE IF EXISTS " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA);
        onCreate(db);
    }


    public ArrayList<Mascota> obtenerMascotas() {

        ArrayList<Mascota> mascotas = new ArrayList<>();

        String query = "SELECT " +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID + ", " +
                ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE + ", " +
                ConstantesBaseDatos.TABLE_MASCOTAS_FOTO + "," +
                " (SELECT COUNT(" + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_NUMERO_PUNTAJE + ")" +
                " FROM " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA +
                " WHERE " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA + "." +
                ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID_MASCOTA + "=" +
                ConstantesBaseDatos.TABLE_MASCOTAS + "." +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID + ") contador_likes" +
                " FROM " + ConstantesBaseDatos.TABLE_MASCOTAS;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()) {
            Mascota masc = new Mascota();
            masc.setId(registros.getInt(0));
            masc.setNombre(registros.getString(1));
            masc.setFoto(registros.getInt(2));
            masc.setPuntos(registros.getInt(3));
            mascotas.add(masc);
        }

        db.close();
        return mascotas;

    }

    public ArrayList<Mascota> obtenerTopMascotasFive() {

        ArrayList<Mascota> mascotas = new ArrayList<>();

        String query = "SELECT " +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID + ", " +
                ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE + ", " +
                ConstantesBaseDatos.TABLE_MASCOTAS_FOTO + "," +
                " (SELECT COUNT(" + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_NUMERO_PUNTAJE + ")" +
                " FROM " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA +
                " WHERE " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA + "." +
                ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID_MASCOTA + "=" +
                ConstantesBaseDatos.TABLE_MASCOTAS + "." +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID + ") contador_likes" +
                " FROM " + ConstantesBaseDatos.TABLE_MASCOTAS +
                " ORDER BY " + "contador_likes" + " DESC" +
                " LIMIT 5";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()) {
            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(registros.getInt(0));
            mascotaActual.setNombre(registros.getString(1));
            mascotaActual.setFoto(registros.getInt(2));
            mascotaActual.setPuntos(registros.getInt(3));
            mascotas.add(mascotaActual);
        }

        db.close();
        return mascotas;

    }


    public void insertarMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_MASCOTAS, null, contentValues);
        db.close();
    }

    public void insertarPuntajeMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA, null, contentValues);
        db.close();
    }

    public int obtenerPuntajeMascota(Mascota mascota){

        int puntaje = 0;

        String query = "SELECT COUNT(" + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_NUMERO_PUNTAJE + ")" +
                " FROM " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA +
                " WHERE " + ConstantesBaseDatos.TABLE_PUNTAJE_MASCOTA_ID_MASCOTA + "=" +
                mascota.getId();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        if (registros.moveToNext()) {
            puntaje = registros.getInt(0);
        }

        db.close();

        return puntaje;
    }

}
